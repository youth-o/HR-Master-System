package com.example.hr_master.enumList;

public enum WorkLocation {
    서한ENP, 기획본부, 서한이노빌리티, 한국무브넥스, 캄텍
}
