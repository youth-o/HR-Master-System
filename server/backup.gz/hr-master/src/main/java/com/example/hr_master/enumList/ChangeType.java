package com.example.hr_master.enumList;

public enum ChangeType {
    부서이동, 직급변경, 기타
}