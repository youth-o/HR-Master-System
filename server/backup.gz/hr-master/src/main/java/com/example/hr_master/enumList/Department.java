package com.example.hr_master.enumList;

public enum Department {
    인사, IT기획, 품질, 공정기술, 안전, 생산관리, 영업, 협력업체관리
}
