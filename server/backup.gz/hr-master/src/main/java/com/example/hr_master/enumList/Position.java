package com.example.hr_master.enumList;

public enum Position {
    인턴, 사원, 주임, 대리, 과장, 차장, 부장, 이사, 사장
}
